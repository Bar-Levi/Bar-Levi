
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// post-op-meds/netlify/lib/push-shared.ts
import { getStore } from "@netlify/blobs";
import webpush from "web-push";
function vapidConfigured() {
  return !!(process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY);
}
var json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });

// post-op-meds/netlify/functions/push-key.ts
var config = { path: "/api/push-key" };
var push_key_default = async () => vapidConfigured() ? json({ publicKey: process.env.VAPID_PUBLIC_KEY }) : json({ error: "push not configured" }, 503);
export {
  config,
  push_key_default as default
};
