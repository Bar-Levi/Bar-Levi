
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// post-op-meds/netlify/lib/push-shared.ts
import { getStore } from "@netlify/blobs";
import webpush from "web-push";
var store = () => getStore({ name: "push-subscriptions", consistency: "strong" });
function vapidConfigured() {
  return !!(process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY);
}
async function keyFor(endpoint) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(endpoint));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
var json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
function validSubscription(s) {
  const x = s;
  return !!x && typeof x.endpoint === "string" && x.endpoint.startsWith("https://") && x.endpoint.length < 1e3 && typeof x.keys?.p256dh === "string" && typeof x.keys?.auth === "string";
}

// post-op-meds/netlify/functions/push-sync.ts
var config = { path: "/api/push-sync" };
var push_sync_default = async (req) => {
  if (req.method !== "POST") return json({ error: "method" }, 405);
  if (!vapidConfigured()) return json({ error: "push not configured" }, 503);
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "bad json" }, 400);
  }
  if (!validSubscription(body.subscription)) return json({ error: "bad subscription" }, 400);
  const key = await keyFor(body.subscription.endpoint);
  if (body.unsubscribe) {
    await store().delete(key);
    return json({ ok: true });
  }
  const now = Date.now();
  const reminders = (Array.isArray(body.reminders) ? body.reminders : []).slice(0, 10).filter((r) => !!r && typeof r.at === "number" && typeof r.title === "string" && typeof r.body === "string" && typeof r.tag === "string").filter((r) => r.at > now - 6 * 36e5 && r.at < now + 3 * 864e5).map((r) => ({ tag: r.tag.slice(0, 40), at: r.at, title: r.title.slice(0, 120), body: r.body.slice(0, 240) }));
  const prev = await store().get(key, { type: "json" });
  for (const r of reminders) {
    if (prev?.reminders.some((p) => p.tag === r.tag && p.at === r.at && p.sent)) r.sent = true;
  }
  const rec = { subscription: body.subscription, reminders, updatedAt: now };
  await store().setJSON(key, rec);
  return json({ ok: true, scheduled: reminders.filter((r) => !r.sent).length });
};
export {
  config,
  push_sync_default as default
};
