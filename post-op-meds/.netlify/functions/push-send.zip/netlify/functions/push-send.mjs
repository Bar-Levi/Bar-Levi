
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// post-op-meds/netlify/lib/push-shared.ts
import { getStore } from "@netlify/blobs";
import webpush from "web-push";
var store = () => getStore({ name: "push-subscriptions", consistency: "strong" });
function vapidConfigured() {
  return !!(process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY);
}
function initWebPush() {
  webpush.setVapidDetails(
    process.env.VAPID_SUBJECT || "mailto:noreply@example.com",
    process.env.VAPID_PUBLIC_KEY,
    process.env.VAPID_PRIVATE_KEY
  );
  return webpush;
}

// post-op-meds/netlify/functions/push-send.ts
var config = { schedule: "* * * * *" };
var STALE_MS = 6 * 36e5;
var FORGET_MS = 14 * 864e5;
var push_send_default = async () => {
  if (!vapidConfigured()) return;
  const wp = initWebPush();
  const s = store();
  const now = Date.now();
  const { blobs } = await s.list();
  await Promise.all(blobs.map(async ({ key }) => {
    const rec = await s.get(key, { type: "json" });
    if (!rec) return;
    if (now - rec.updatedAt > FORGET_MS) {
      await s.delete(key);
      return;
    }
    const due = rec.reminders.filter((r) => !r.sent && r.at <= now && now - r.at < STALE_MS);
    if (due.length === 0) return;
    for (const r of due) {
      r.sent = true;
    }
    await s.setJSON(key, rec);
    for (const r of due) {
      try {
        await wp.sendNotification(
          rec.subscription,
          JSON.stringify({ title: r.title, body: r.body, tag: `med:${r.tag}` }),
          { TTL: 3600, urgency: "high" }
        );
      } catch (e) {
        const code = e.statusCode;
        if (code === 404 || code === 410) {
          await s.delete(key);
          return;
        }
        console.error("push failed", code);
      }
    }
  }));
};
export {
  config,
  push_send_default as default
};
